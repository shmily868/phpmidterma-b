<?php
$no=$_POST["no"];
$uid=$_POST["uid"];
$upwd=$_POST["upwd"];
$email=$_POST["email"];
$phnum=$_POST["phnum"];

require('include.inc');
$sql ="UPDATE user SET  upwd ='$upwd', email = '$email', phnum = '$phnum'  WHERE no=".$no;
mysqli_query($link, $sql);
	
	

	$read= "SELECT * FROM user";
	$readresult = mysqli_query($link, $read);
	echo "<table border='1'>";
	echo "<tr> <td>密碼</td> <td>EMail</td> <td>電話號碼</td> <td>更新資料</td> <td>刪除資料</td></tr>";
while($result=mysqli_fetch_array($readresult)){
	echo "<tr>";
	echo "<td>".$result[2]."</td> <td>".$result[3]."</td> <td>".$result[4]."</td>";

	echo "<td><a href='update.php?no=".$result[0]."'>更新資料</td>";
	echo "<td><a href='checkdel.php?no=".$result[0]."'>刪除資料</a></td>";
	echo "</tr>";
}
	echo "</table>";

?>
<p><a href="index.php">回頁面</a></p>