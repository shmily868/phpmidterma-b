<?php
$no=$_GET["no"];
$uid=$_POST["uid"];
$upwd=$_POST["upwd"];
$email=$_POST["email"];
$phnum=$_POST["phnum"];

require('include.inc');

$read="SELECT * FROM user WHERE no=".$no;
$readresult=mysqli_query($link,$read);
$result=mysqli_fetch_array($readresult);

echo "<form action='profile.php' method='POST'>";
echo "編號:".$result[0]."<br/>";
echo "<input type='hidden' name='no' value='".$result[0]."'>";

echo "密碼:<input type='password' name='upwd' value='".$result[2]."'><br/>";
echo "EMail:<input type='email' name='email' value='".$result[3]."'><br/>";
echo "電話號碼:<input type='num' name='phnum' value='".$result[4]."'><br/>";

echo "<input type='submit' value='更新'>";
echo "<input type='reset'>";
echo "</form>";

?>
<p><a href="profile.php">回修改頁面</a></p>