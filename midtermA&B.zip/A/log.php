<html>
<head>
<title>登入</title>
<meta charset="UTF-8"/>
</head>
<body>
<form action="" method="post">

<center>
<h1>登入</h1>
<input type="text" name="uid" onkeyup="value=value.replace(/[\W]/g,'')" placeholder="請輸入您的帳號"><p>
<input type="password" name="upwd" onkeyup="value=value.replace(/[\W]/g,'')"  placeholder="請輸入您的密碼"><p>
<input type="submit"  onClick="">
<input type="reset"  onClick="index2.php"><p>


</center>
</form>
<?php

session_start();
require('include.inc');

if(isset($_POST["uid"])){
	$uid=$_POST["uid"];
	$upwd=$_POST["upwd"];


$sql="SELECT * from user WHERE uid='$uid'AND upwd='$upwd'"; 
$result=mysqli_query($link,$sql);

$row=mysqli_num_rows($result);

if($row){    
	echo "登入成功!";
	$_SEESION['check']="yes";
	header('Location:index.php');
}else{

	echo "<script language = 'javascript'>"; 
	echo "alert('輸入錯誤！請重新輸入！');location.href='log.php';"; 
	echo "</script>"; 

 


}

}

?>
</body>
</html>
