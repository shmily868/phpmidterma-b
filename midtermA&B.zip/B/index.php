<?php

echo "A=1 , B=2";
echo "</br>";

function add($A,$B){

	echo '$A+$B = ';
	echo $A+$B.'<br>';

	echo '$A-$B = ';
	echo $A-$B.'<br>';

	echo '$A*$B = ';
	echo $A*$B.'<br>';

	echo '$A/$B = ';
	echo $A/$B;
	echo "</br>";

	echo '($A+$B)*($A+$B) = ';
	echo ($A+$B)*($A+$B);

	}
add("1","2");



echo "</br></br>";
echo "這是FUNCTION(B3)";
echo "</br>";


function b3($c,$d,$e,$f,$g,$h){

	echo '(30+25)^2 = ';
	echo ($c+$d)*($c+$d).'<br>';

	echo '(8+1)^2 = ';
	echo ($e+$f)*($e+$f).'<br>';

	echo '(0+1)^2 = ';
	echo ($g+$h)*($g+$h);
}
b3("30","25","8","1","0","1");


?>